/*
 * Copyright (C) 2014 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.futo.inputmethod.latin.utils;

import static org.junit.Assert.assertEquals;

import androidx.test.filters.SmallTest;
import androidx.test.runner.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.Arrays;
import java.util.List;

@SmallTest
@RunWith(AndroidJUnit4.class)
public class JsonUtilsTests {
    @Test
    public void testJsonUtils() {
        final Object[] objs = new Object[] { 1, "aaa", "bbb", 3 };
        final List<Object> objArray = Arrays.asList(objs);
        final String str = JsonUtils.listToJsonStr(objArray);
        final List<Object> newObjArray = JsonUtils.jsonStrToList(str);
        for (int i = 0; i < objs.length; ++i) {
            assertEquals(objs[i], newObjArray.get(i));
        }
    }
}
