package org.futo.inputmethod.latin.godfather

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.futo.inputmethod.latin.RichInputConnection

/**
 * The Godfather converter, plugged into FUTO Keyboard.
 *
 * Converts the text in the box into the RLO / ZWJ form (see [Converter]), live points counter,
 * auto-convert after a pause, convert-on-send, and "put the plain text back when you type again".
 * @mentions at the start of the box are left alone so the app still recognises the tag.
 *
 * InputLogic calls [beforeInput], [afterInput], [onSelection] and [convertBeforeSend];
 * the top panel ([GodfatherBar]) reads the state below.
 */
object Godfather {
    private const val MAX_PREVIEW = 600          // longer text is not converted or previewed
    private const val AUTO_DELAY_MS = 700L
    private const val EXTRAS_MS = 6000L

    // ---- state the top panel shows
    var rlo by mutableStateOf(true)
        private set
    var zwj by mutableStateOf(true)
        private set
    var auto by mutableStateOf(true)
        private set
    var points by mutableIntStateOf(0)
        private set
    var chars by mutableIntStateOf(0)
        private set
    var ready by mutableStateOf(false)           // converted, waiting to be sent
        private set
    var tooLong by mutableStateOf(false)
        private set
    var extrasShown by mutableStateOf(false)     // RLO / ZWJ switches, shown by holding AUTO
        private set

    private val handler = Handler(Looper.getMainLooper())
    private var prefs: SharedPreferences? = null
    private var connection: RichInputConnection? = null
    private var finishComposing: Runnable? = null

    private var undoOriginal: String? = null
    private var undoConverted: String? = null
    private var undoKeep = 0
    private var lastPreview = ""

    private val autoRunnable = Runnable {
        try { autoConvertNow() } catch (e: Exception) { }
    }
    private val pointsRunnable = Runnable {
        try { refreshStatus() } catch (e: Exception) { }
    }
    private val hideExtras = Runnable { setExtras(false) }

    // ------------------------------------------------------------------ setup

    @JvmStatic
    fun setup(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("godfather", Context.MODE_PRIVATE)
        prefs = p
        rlo = p.getBoolean("rlo", true)
        zwj = p.getBoolean("zwj", true)
        auto = p.getBoolean("auto", true)
    }

    @JvmStatic
    fun attach(conn: RichInputConnection, finish: Runnable) {
        connection = conn
        finishComposing = finish
    }

    @JvmStatic
    fun postDelayed(r: Runnable, ms: Long) {
        handler.postDelayed(r, ms)
    }

    // ------------------------------------------------------------------ hooks called by InputLogic

    /**
     * Before a key is handled. If it edits text, put the plain text back first.
     * Returns true if it did, so the caller can pick the word at the cursor up again.
     */
    @JvmStatic
    fun beforeInput(editsText: Boolean): Boolean {
        handler.removeCallbacks(autoRunnable)
        if (!editsText) return false
        return restoreIfConverted()
    }

    /** If the box holds our converted text, put the plain text back. True if it did. */
    @JvmStatic
    fun restoreIfConverted(): Boolean {
        val conn = connection ?: return false
        val converted = undoConverted ?: return false
        return if (fieldText(conn) == converted) {
            restorePlain(conn)
            true
        } else {
            clearUndo()
            false
        }
    }

    @JvmStatic
    fun afterInput() {
        schedulePoints()
        scheduleAuto()
    }

    @JvmStatic
    fun onSelection() {
        schedulePoints()
    }

    /** Called when Enter is about to send. Returns true if it converted (the caller then waits a moment). */
    @JvmStatic
    fun convertBeforeSend(): Boolean {
        val conn = connection ?: return false
        handler.removeCallbacks(autoRunnable)
        if (!auto || undoConverted != null) return false
        val ok = try { convertNow(conn, fieldText(conn), false) } catch (e: Exception) { false }
        refreshStatus()
        return ok
    }

    // ------------------------------------------------------------------ top panel actions

    fun flip(name: String) {
        val p = prefs ?: return
        val now = !p.getBoolean(name, true)
        p.edit().putBoolean(name, now).apply()
        when (name) {
            "rlo" -> rlo = now
            "zwj" -> zwj = now
            "auto" -> auto = now
        }
        handler.removeCallbacks(autoRunnable)
        val conn = connection
        if (conn != null && undoConverted != null) restorePlain(conn)   // output depends on the switches: start again from plain text
        lastPreview = ""
        schedulePoints()
        scheduleAuto()
    }

    fun setExtras(show: Boolean) {
        extrasShown = show
        handler.removeCallbacks(hideExtras)
        if (show) handler.postDelayed(hideExtras, EXTRAS_MS)
    }

    fun keepExtrasOpen() {
        if (extrasShown) setExtras(true)
    }

    /** Tap on the counter: convert now, or put the plain text back. */
    fun toggleConvert() {
        val conn = connection ?: return
        handler.removeCallbacks(autoRunnable)
        if (undoConverted != null) {
            restorePlain(conn)
            return
        }
        convertNow(conn, fieldText(conn), true)
        refreshStatus()
    }

    // ------------------------------------------------------------------ scheduling

    private fun scheduleAuto() {
        handler.removeCallbacks(autoRunnable)
        if (auto && undoConverted == null) handler.postDelayed(autoRunnable, AUTO_DELAY_MS)
    }

    private fun schedulePoints() {
        handler.removeCallbacks(pointsRunnable)
        handler.postDelayed(pointsRunnable, 40)
    }

    private fun autoConvertNow() {
        val conn = connection ?: return
        if (!auto || undoConverted != null) return
        // Converting rewrites the whole field and parks the cursor at the end. If you are editing
        // in the middle (or have a selection) that would make the text jump, so wait.
        if (conn.hasSelection()) return
        val after = conn.getTextAfterCursor(1, 0)
        if (after != null && after.isNotEmpty()) return
        convertNow(conn, fieldText(conn), true)
        refreshStatus()
    }

    // ------------------------------------------------------------------ convert / restore

    private fun fieldText(conn: RichInputConnection): String {
        val before = conn.getTextBeforeCursor(MAX_PREVIEW + 1, 0)
        val after = conn.getTextAfterCursor(MAX_PREVIEW + 1, 0)
        return (before?.toString() ?: "") + (after?.toString() ?: "")
    }

    /**
     * How many characters at the start are @mentions (plus the badges/emoji after each name and the
     * spaces). Those belong to the app: it needs them untouched to notify the person you tagged.
     */
    private fun mentionPrefixLen(t: String): Int {
        val n = t.length
        var i = 0
        var end = 0
        while (i < n) {
            while (i < n && Character.isWhitespace(t[i])) i++
            if (i >= n || t[i] != '@') break
            while (i < n && !Character.isWhitespace(t[i])) i++          // the @name
            end = i
            while (true) {                                              // badges / emoji after the name
                var j = i
                while (j < n && Character.isWhitespace(t[j])) j++
                if (j >= n || j == i || t[j] == '@') break
                var k = j
                var word = false
                while (k < n && !Character.isWhitespace(t[k])) {
                    val cp = t.codePointAt(k)
                    if (Character.isLetterOrDigit(cp)) word = true
                    k += Character.charCount(cp)
                }
                if (word) break                                         // your own words start here
                i = k
                end = k
            }
        }
        if (end > 0) while (end < n && Character.isWhitespace(t[end])) end++
        return end
    }

    /** Replace the last [oldTailLen] characters (everything after the @mentions), cursor ends at the end. */
    private fun replaceTail(conn: RichInputConnection, oldTailLen: Int, newTail: String) {
        conn.beginBatchEdit()
        val after = conn.getTextAfterCursor(MAX_PREVIEW + 1, 0)
        val al = after?.length ?: 0
        if (al > 0) {
            val end = conn.expectedSelectionEnd + al
            conn.setSelection(end, end)
        }
        conn.deleteTextBeforeCursor(oldTailLen)
        conn.commitText(newTail, 1)
        conn.endBatchEdit()
        // FUTO queues edits and only applies them on send(). Without this the converted text
        // never reaches the box when we convert from a timer or from the panel.
        conn.send()
    }

    private fun convertNow(conn: RichInputConnection, plain: String, finish: Boolean): Boolean {
        if (plain.isEmpty() || plain.length > MAX_PREVIEW) return false
        if (conn.hasSelection()) return false
        if (plain.indexOf('\u2066') >= 0 || plain.indexOf('\u202e') >= 0) return false   // already converted
        val keep = mentionPrefixLen(plain)
        val body = plain.substring(keep)
        if (body.trim().isEmpty()) return false          // only a tag so far: nothing of yours to convert
        val r = Converter.convert(body, rlo, zwj, plain.substring(0, keep))
        // only now (we really are converting) stop composing the word; pausing with nothing to
        // convert must not disturb the suggestions
        if (finish) finishComposing?.run()
        replaceTail(conn, body.length, r.text)
        undoOriginal = plain
        undoConverted = plain.substring(0, keep) + r.text
        undoKeep = keep
        lastPreview = ""
        refreshStatus()
        return true
    }

    private fun restorePlain(conn: RichInputConnection) {
        val plain = undoOriginal
        val keep = undoKeep
        val convertedTail = (undoConverted?.length ?: 0) - keep
        clearUndo()
        if (plain != null) {
            replaceTail(conn, convertedTail, plain.substring(minOf(keep, plain.length)))
        }
        lastPreview = ""
        refreshStatus()
    }

    private fun clearUndo() {
        undoOriginal = null
        undoConverted = null
        undoKeep = 0
    }

    // ------------------------------------------------------------------ live counter

    private fun refreshStatus() {
        val budget = Converter.POINT_BUDGET
        val o = undoOriginal
        val c = undoConverted
        if (o != null && c != null) {                               // converted and ready to send
            chars = o.codePointCount(0, o.length)
            points = c.codePointCount(0, c.length)
            ready = true
            tooLong = false
            return
        }
        ready = false
        val conn = connection ?: return
        val all = fieldText(conn)
        if (all.indexOf('\u2066') >= 0 || all.indexOf('\u202e') >= 0) {   // converted text that was already in the box
            chars = all.codePointCount(0, all.length)
            points = chars
            ready = true
            tooLong = false
            return
        }
        val key = "$rlo|$zwj|$all"
        if (key == lastPreview) return                              // nothing changed since the last count
        lastPreview = key

        val n = all.codePointCount(0, all.length)
        chars = n
        when {
            all.isEmpty() -> {
                points = 0
                tooLong = false
            }
            all.length > MAX_PREVIEW -> {
                points = budget + 1
                tooLong = true
            }
            else -> {
                tooLong = false
                val keep = mentionPrefixLen(all)
                val body = all.substring(keep)
                points = if (body.isBlank()) n
                else all.codePointCount(0, keep) + Converter.convert(body, rlo, zwj, all.substring(0, keep)).points
            }
        }
    }
}
