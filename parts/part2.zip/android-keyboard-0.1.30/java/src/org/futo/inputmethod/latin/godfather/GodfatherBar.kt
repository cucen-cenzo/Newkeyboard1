package org.futo.inputmethod.latin.godfather

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.futo.inputmethod.latin.uix.LocalKeyboardScheme

private val Amber = Color(0xFFFFB86B)
private val Red = Color(0xFFFF6B6B)

/**
 * The converter tools, shown at the right end of FUTO's top row (next to the favourite actions):
 * AUTO (hold it to show the RLO / ZWJ switches) and the live points counter
 * (tap it to convert now / put the plain text back). It uses the keyboard's own theme colours.
 */
@Composable
fun GodfatherTools() {
    val haptic = LocalHapticFeedback.current

    Row(
        Modifier
            .fillMaxHeight()
            .padding(start = 4.dp, end = 8.dp, top = 5.dp, bottom = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (Godfather.extrasShown) {
            SwitchPill(Modifier.width(52.dp), "RLO", Godfather.rlo) {
                Godfather.flip("rlo")
                Godfather.keepExtrasOpen()
            }
            SwitchPill(Modifier.width(52.dp), "ZWJ", Godfather.zwj) {
                Godfather.flip("zwj")
                Godfather.keepExtrasOpen()
            }
        }

        SwitchPill(
            Modifier.width(60.dp), "AUTO", Godfather.auto,
            onLongClick = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                Godfather.setExtras(!Godfather.extrasShown)
            }
        ) { Godfather.flip("auto") }

        Counter(Modifier.width(96.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Pill(
    modifier: Modifier,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    highlighted: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val scheme = LocalKeyboardScheme.current
    Box(
        modifier
            .fillMaxHeight()
            .clip(CircleShape)
            .background(if (highlighted) scheme.primary.copy(alpha = 0.18f) else scheme.keyboardContainer)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
private fun SwitchPill(
    modifier: Modifier,
    label: String,
    on: Boolean,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    val scheme = LocalKeyboardScheme.current
    Pill(modifier, onClick = onClick, onLongClick = onLongClick, highlighted = on) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(if (on) scheme.primary else scheme.onKeyboardContainer.copy(alpha = 0.35f))
            )
            Spacer(Modifier.width(4.dp))
            Text(
                label,
                fontSize = 11.sp,
                lineHeight = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (on) scheme.onKeyboardContainer else scheme.onKeyboardContainer.copy(alpha = 0.55f),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun Counter(modifier: Modifier) {
    val scheme = LocalKeyboardScheme.current
    val budget = Converter.POINT_BUDGET
    val points = Godfather.points
    val tint = when {
        points > budget -> Red
        points * 100 > budget * 80 -> Amber
        else -> scheme.primary
    }
    val main = if (Godfather.tooLong) "too long" else "$points/$budget pts"
    val sub = if (Godfather.ready) "${Godfather.chars} chars · ready" else "${Godfather.chars} chars"

    Pill(modifier, onClick = { Godfather.toggleConvert() }, highlighted = Godfather.ready) {
        Box(Modifier.fillMaxSize()) {
            // fixed line heights so a big system font size cannot push the second line out of the pill
            Column(
                Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    main,
                    fontSize = 11.sp,
                    lineHeight = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (points > budget) Red else scheme.onKeyboardContainer,
                    maxLines = 1
                )
                Text(
                    sub,
                    fontSize = 8.sp,
                    lineHeight = 9.sp,
                    color = scheme.onKeyboardContainer.copy(alpha = 0.6f),
                    maxLines = 1
                )
            }
            // progress bar sits on the bottom edge of the pill
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(start = 14.dp, end = 14.dp, bottom = 2.dp)
                    .fillMaxWidth()
                    .height(1.5.dp)
                    .clip(CircleShape)
                    .background(scheme.onKeyboardContainer.copy(alpha = 0.12f))
            ) {
                Box(
                    Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(minOf(1f, points / budget.toFloat()))
                        .background(tint)
                )
            }
        }
    }
}
