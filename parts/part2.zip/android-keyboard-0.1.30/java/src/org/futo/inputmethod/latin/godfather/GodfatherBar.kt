package org.futo.inputmethod.latin.godfather

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.futo.inputmethod.latin.uix.Action
import org.futo.inputmethod.latin.uix.LocalKeyboardScheme

private val Amber = Color(0xFFFFB86B)
private val Red = Color(0xFFFF6B6B)

/**
 * The top panel: clipboard, emoji, AUTO (hold it to show the RLO / ZWJ switches) and the live
 * points counter (tap to convert now / put the plain text back).
 * It uses the keyboard's own theme colours.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GodfatherBar(
    clipboardAction: Action,
    emojiAction: Action,
    onActionActivated: (Action) -> Unit
) {
    val scheme = LocalKeyboardScheme.current
    val haptic = LocalHapticFeedback.current

    Row(
        Modifier
            .fillMaxWidth()
            .height(46.dp)
            .padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Pill(Modifier.weight(1.6f), onClick = { onActionActivated(clipboardAction) }) {
            Icon(
                painter = painterResource(id = clipboardAction.icon),
                contentDescription = "clipboard",
                tint = scheme.onKeyboardContainer,
                modifier = Modifier.size(24.dp)
            )
        }
        Pill(Modifier.weight(1.6f), onClick = { onActionActivated(emojiAction) }) {
            Icon(
                painter = painterResource(id = emojiAction.icon),
                contentDescription = "emoji",
                tint = scheme.onKeyboardContainer,
                modifier = Modifier.size(24.dp)
            )
        }

        if (Godfather.extrasShown) {
            SwitchPill(Modifier.weight(1.0f), "RLO", Godfather.rlo) {
                Godfather.flip("rlo")
                Godfather.keepExtrasOpen()
            }
            SwitchPill(Modifier.weight(1.0f), "ZWJ", Godfather.zwj) {
                Godfather.flip("zwj")
                Godfather.keepExtrasOpen()
            }
        }

        SwitchPill(
            Modifier.weight(1.1f), "AUTO", Godfather.auto,
            onLongClick = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                Godfather.setExtras(!Godfather.extrasShown)
            }
        ) { Godfather.flip("auto") }

        Counter(Modifier.weight(2.0f))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Pill(
    modifier: Modifier,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    outlined: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val scheme = LocalKeyboardScheme.current
    Box(
        modifier
            .fillMaxHeight()
            .clip(CircleShape)
            .background(if (outlined) scheme.primary.copy(alpha = 0.18f) else scheme.keyboardContainer)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
private fun SwitchPill(
    modifier: Modifier,
    label: String,
    on: Boolean,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    val scheme = LocalKeyboardScheme.current
    Pill(modifier, onClick = onClick, onLongClick = onLongClick, outlined = on) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(if (on) scheme.primary else scheme.onKeyboardContainer.copy(alpha = 0.35f))
            )
            Spacer(Modifier.width(5.dp))
            Text(
                label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (on) scheme.onKeyboardContainer else scheme.onKeyboardContainer.copy(alpha = 0.55f),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun Counter(modifier: Modifier) {
    val scheme = LocalKeyboardScheme.current
    val budget = Converter.POINT_BUDGET
    val points = Godfather.points
    val tint = when {
        points > budget -> Red
        points * 100 > budget * 80 -> Amber
        else -> scheme.primary
    }
    val main = if (Godfather.tooLong) "too long" else "$points/$budget pts"
    val sub = if (Godfather.ready) "${Godfather.chars} chars · ready" else "${Godfather.chars} chars"

    Pill(modifier, onClick = { Godfather.toggleConvert() }, outlined = Godfather.ready) {
        Column(
            Modifier.fillMaxHeight().fillMaxWidth().padding(horizontal = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                main,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (points > budget) Red else scheme.onKeyboardContainer,
                maxLines = 1
            )
            Text(
                sub,
                fontSize = 10.sp,
                color = scheme.onKeyboardContainer.copy(alpha = 0.6f),
                maxLines = 1
            )
            Spacer(Modifier.height(2.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .clip(CircleShape)
                    .background(scheme.onKeyboardContainer.copy(alpha = 0.12f))
            ) {
                Box(
                    Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(minOf(1f, points / budget.toFloat()))
                        .background(tint)
                )
            }
        }
    }
}
